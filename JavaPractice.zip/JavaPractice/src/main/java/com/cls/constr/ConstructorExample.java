package com.cls.constr;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Calendar;

public class ConstructorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// int no=13;
		/*
		 * Cons con = new Cons(); con.setName("Sneha"); String s=con.getName();
		 * System.out.println(s);
		 */

		String[] snl_add = { "A", "B", "C", "D", "E", "F", "G", "H", "I" };
		String[] bics = { "o", "p", "q", "r", "s", "t", "u" };
		/*
		 * System.out.println(Arrays.toString(nums)); int[] arr1 =
		 * Arrays.copyOfRange(nums, 10,nums.length);
		 * System.out.println(Arrays.toString(arr1));
		 */
		int cs_max_mi_prep_dns = 4;
		int cs_max_fin_prep_bics = 50;

		int cs_mi_prep_messages = snl_add.length / cs_max_mi_prep_dns;
		int cs_mi_pre_rem = snl_add.length % cs_max_mi_prep_dns;
		if (cs_mi_pre_rem != 0) {
			cs_mi_prep_messages = cs_mi_prep_messages + 1;
		}
		
		int cs_fin_prep_messages = bics.length / cs_max_fin_prep_bics;
		int cs_fin_prep_rem = bics.length % cs_max_fin_prep_bics;
		if (cs_fin_prep_rem != 0) {
			cs_fin_prep_messages = cs_fin_prep_messages + 1;
		}
		
		int sequence = 2390990;
		String seq = null;
		if (String.valueOf(sequence).length() < 9) {
			DecimalFormat df = new DecimalFormat("000000000");
			seq = df.format(sequence);
		}
		else {
			seq = Integer.toString(sequence);
		}
		
		int total_cs_prep_messages = cs_mi_prep_messages + cs_fin_prep_messages;
		
		
		int month = Calendar.getInstance().get(Calendar.MONTH);
		String mon;
		if (month < 10) {
			DecimalFormat df = new DecimalFormat("00");
			mon = df.format(month);
		}
		else {
			mon = Integer.toString(month);
		}
		
		String default_msg_ref = "M" + Integer.toString(Calendar.getInstance().get(Calendar.YEAR)) + mon + seq ;
		System.out.println(default_msg_ref);
		int len_dns = snl_add.length;
		int len_bics = bics.length;
		String[] dns;
		String[] all_bics;
		for (int i = 0; i < cs_mi_prep_messages; i++) {

			String message = "";
			String header = String.format("PREPARE_FOR_COLD_START %s %d of %d", default_msg_ref, i + 1,
					total_cs_prep_messages);
			message = message + header;
			if (len_dns > cs_max_mi_prep_dns) {
				dns = Arrays.copyOfRange(snl_add, i * cs_max_mi_prep_dns, i * cs_max_mi_prep_dns + cs_max_mi_prep_dns);
				len_dns = len_dns - cs_max_mi_prep_dns;
			} else {
				dns = Arrays.copyOfRange(snl_add, i * cs_max_mi_prep_dns, snl_add.length);
			}
			for (String dn : dns) {
				String cs_mi_prep_msg = String.format("COLD_DN %s", dn);
				message = message + "\n" + cs_mi_prep_msg;
			}

			System.out.println(message);
		}

		for (int i = 0; i < cs_fin_prep_messages; i++) {

			String message = "";
			String header = String.format("PREPARE_FOR_COLD_START %s %d of %d", default_msg_ref, i + cs_mi_prep_messages+1 ,
					total_cs_prep_messages);
			message = message + header;
			if (len_bics > cs_max_fin_prep_bics) {
				all_bics = Arrays.copyOfRange(bics, i * cs_max_fin_prep_bics, i * cs_max_fin_prep_bics + cs_max_fin_prep_bics);
				len_dns = len_dns - cs_max_mi_prep_dns;
			} else {
				all_bics = Arrays.copyOfRange(bics, i * cs_max_fin_prep_bics, bics.length);
			}
			for (String bic : all_bics) {
				String cs_fin_prep_msg = String.format("COLD_DN %s", bic);
				message = message + "\n" + cs_fin_prep_msg;
			}

			System.out.println(message);
		}

	}

}
