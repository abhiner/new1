package com.cls.constr;

public class Cons {
	
		int roll;
		String name;
		
//		Cons() {
//			System.out.println("In contructor");
//			this.roll=15;
//			this.name="Sneha";
//			System.out.println(roll);
//			System.out.println(name);
//		}
//		
//		Cons(int roll){
//			this.roll=roll;
//			System.out.println(this.roll);
//		}
//		
//		public void isEligible() {
//			if(roll>10) {
//				System.out.println("Eligible");
//				System.out.println(roll);
//				
//			}
//		}

		public Cons() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Cons(int roll, String name) {
			super();
			this.roll = roll;
			this.name = name;
		}

		public int getRoll() {
			return roll;
		}

		public void setRoll(int roll) {
			this.roll = roll;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
		
		
	
}
